# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src/pyspark'}

packages = \
['neuralmed_raw', 'neuralmed_raw.utils']

package_data = \
{'': ['*']}

install_requires = \
['pytz>=2023.3,<2024.0']

setup_kwargs = {
    'name': 'neuralmed-desafio',
    'version': '0.0.1',
    'description': 'Desafio de Engeharia de dados',
    'long_description': None,
    'author': 'Alan',
    'author_email': 'alan.viegas@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
